Download datasets bike_routes.json, restaurants.csv and (if available) restaurants.json from Teams :

https://ulavaldti.sharepoint.com/:f:/r/sites/GLO-7035Basesdedonnesavances/Documents%20partages/General/datasets?csf=1&web=1&e=uRLCiR